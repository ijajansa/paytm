<div class="nk-footer">
    <div class="container-fluid">
        <div class="nk-footer-wrap">
            <div class="nk-footer-copyright"> Powered by <a href="https://hayawebtech.com" target="_blank"><b>HayaWebTech</b></a>
            </div>
        </div>
    </div>
</div>